import { SlashCommandBuilder } from "discord.js";

export default new SlashCommandBuilder()
    .setName("links")
    .setDescription("⚓ Links of the bot")
    .setDescriptionLocalizations({
        "fr": "⚓ Lien du bot"
    })