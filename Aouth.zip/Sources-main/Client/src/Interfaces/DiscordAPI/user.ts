export default interface User {
    id: string
    username: string
    avatar: string
    discriminator: string
    flags: number
    locale: string
    messsage: string
    code: number
}