export default {
    API_BASE: "https://discord.com/api",
    REDIRECTION_URI: ""
}