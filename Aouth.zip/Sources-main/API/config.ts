export default {
    "redirect_not_found": "https://oa2.dev"
}